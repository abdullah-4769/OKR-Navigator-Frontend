enum GameMode { solo, challenge, campaign, team }

/// Canonical event identifiers across all modes.
/// Use these strings in FCM `data` payloads: { mode: 'solo', event: 'evaluation_success', ... }
class NotificationEvent {
  // Solo
  static const String soloEvaluationSuccess = 'evaluation_success';
  static const String soloEvaluationFailed = 'evaluation_failed';
  static const String soloOverallCompletion = 'overall_completion';

  // Challenge
  static const String challengeInvitation = 'challenge_invitation';
  static const String challengeInvitationResponse =
      'challenge_invitation_response';
  static const String challengeStart = 'challenge_start';
  static const String challengePlayerProgress = 'challenge_player_progress';
  static const String challengeCompletedWinner = 'challenge_completed_winner';
  static const String challengeCompletedLoser = 'challenge_completed_loser';

  // Campaign
  static const String campaignLevelUnlocked = 'campaign_level_unlocked';
  static const String campaignLevelReminder = 'campaign_level_reminder';
  static const String campaignCertReminder = 'campaign_cert_reminder';
  static const String campaignCertComplete = 'campaign_cert_complete';

  // Team
  static const String teamInvitation = 'team_invitation';
  static const String teamAutoJoin = 'team_auto_join';
  static const String teamJoinLeave = 'team_join_leave';
  static const String teamRosterUpdated = 'team_roster_updated';
  static const String teamRoleAssigned = 'team_role_assigned';
  static const String teamGameStart = 'team_game_start';
  static const String teamPlayerProgress = 'team_player_progress';
  static const String teamTimeReminder = 'team_time_reminder';
  static const String teamScoreUpdated = 'team_score_updated';
  static const String teamGameCompleteWinner = 'team_game_complete_winner';
  static const String teamGameCompleteLoser = 'team_game_complete_loser';
}

class NotificationTemplate {
  /// Builds a title/body pair for a given mode+event, using provided variables.
  static ({String title, String body}) build({
    required GameMode mode,
    required String event,
    Map<String, dynamic>? vars,
  }) {
    final v = vars ?? const {};
    switch (mode) {
      case GameMode.solo:
        switch (event) {
          case NotificationEvent.soloEvaluationSuccess:
            return (
              title: 'Level Completed!',
              body:
                  'Congratulations! You successfully completed this evaluation.',
            );
          case NotificationEvent.soloEvaluationFailed:
            final attempts = v['remainingAttempts'] ?? v['attempts'] ?? 'X';
            return (
              title: 'Attempt Incomplete',
              body:
                  'You didn’t pass this evaluation. You have $attempts attempts remaining. Try again!',
            );
          case NotificationEvent.soloOverallCompletion:
            return (
              title: 'Achievement Unlocked!',
              body: 'You’ve completed the solo mode. Great job!',
            );
          default:
            return (
              title: 'Solo Update',
              body: 'Your solo progress has been updated.',
            );
        }
      case GameMode.challenge:
        switch (event) {
          case NotificationEvent.challengeInvitation:
            final host = v['hostName'] ?? 'Host';
            return (
              title: 'New Challenge Invitation',
              body:
                  '$host has invited you to a challenge. Accept or reject to join.',
            );
          case NotificationEvent.challengeInvitationResponse:
            final player = v['playerName'] ?? 'Player';
            final response = v['response'] ?? 'responded';
            return (
              title: 'Challenge Update',
              body: '$player has $response your challenge invitation.',
            );
          case NotificationEvent.challengeStart:
            final host = v['hostName'] ?? 'Host';
            return (
              title: 'Challenge Started',
              body: '$host started the challenge. Good luck!',
            );
          case NotificationEvent.challengePlayerProgress:
            final player = v['playerName'] ?? 'Player';
            return (
              title: 'Player Progress Update',
              body: '$player has started the context challenge. Keep going!',
            );
          case NotificationEvent.challengeCompletedWinner:
            return (
              title: 'Challenge Finished',
              body: 'You won the challenge! Great performance.',
            );
          case NotificationEvent.challengeCompletedLoser:
            return (
              title: 'Challenge Finished',
              body:
                  'Challenge completed. Review your feedback and improve for next time.',
            );
          default:
            return (
              title: 'Challenge Update',
              body: 'Your challenge status changed.',
            );
        }
      case GameMode.campaign:
        switch (event) {
          case NotificationEvent.campaignLevelUnlocked:
            final level = v['level'] ?? 'X';
            return (
              title: 'New Level Unlocked',
              body: 'You unlocked Level $level. Continue your campaign!',
            );
          case NotificationEvent.campaignLevelReminder:
            final level = v['level'] ?? 'X';
            final time = v['timeRemaining'] ?? v['minutes'] ?? 'Y';
            return (
              title: 'Level Progress Reminder',
              body: 'Level $level in progress. Time remaining: $time minutes.',
            );
          case NotificationEvent.campaignCertReminder:
            final time = v['timeRemaining'] ?? v['minutes'] ?? 'X';
            return (
              title: 'Certification in Progress',
              body:
                  'Level 3 Certification ongoing. Time remaining: $time minutes.',
            );
          case NotificationEvent.campaignCertComplete:
            return (
              title: 'Certification Complete',
              body:
                  'Congratulations! You’ve completed the certification and earned your badge.',
            );
          default:
            return (
              title: 'Campaign Update',
              body: 'Your campaign progress changed.',
            );
        }
      case GameMode.team:
        switch (event) {
          case NotificationEvent.teamInvitation:
            final host = v['hostName'] ?? 'Host';
            return (
              title: 'Team Invitation',
              body:
                  '$host invites you to join the team. Accept or auto-join if allowed.',
            );
          case NotificationEvent.teamAutoJoin:
            final host = v['hostName'] ?? 'Host';
            return (
              title: 'Auto-Joined Team',
              body: 'You have been automatically added to the team by $host.',
            );
          case NotificationEvent.teamJoinLeave:
            final player = v['playerName'] ?? 'Player';
            final action = v['action'] ?? 'joined';
            return (
              title: 'Team Update',
              body: '$player has $action the team.',
            );
          case NotificationEvent.teamRosterUpdated:
            return (
              title: 'Team Roster Updated',
              body:
                  'Team members have changed before the game started. Check the updated team list.',
            );
          case NotificationEvent.teamRoleAssigned:
            final role = v['roleName'] ?? 'Role';
            return (
              title: 'Role Assigned',
              body: 'You have been assigned the role: $role.',
            );
          case NotificationEvent.teamGameStart:
            return (
              title: 'Team Game Started',
              body: 'Your team game has started. Good luck, team!',
            );
          case NotificationEvent.teamPlayerProgress:
            final player = v['playerName'] ?? 'Player';
            return (
              title: 'Team Progress Update',
              body:
                  '$player started a context challenge. Keep up the momentum!',
            );
          case NotificationEvent.teamTimeReminder:
            final time = v['timeRemaining'] ?? v['minutes'] ?? 'X';
            return (
              title: 'Time Reminder',
              body:
                  'Team game in progress. Remaining time: $time minutes. Keep going!',
            );
          case NotificationEvent.teamScoreUpdated:
            final player = v['playerName'] ?? 'Player';
            return (
              title: 'Score Updated',
              body: '$player submitted their score. Team score updated.',
            );
          case NotificationEvent.teamGameCompleteWinner:
            return (
              title: 'Team Game Complete',
              body: 'Your team won! Congratulations!',
            );
          case NotificationEvent.teamGameCompleteLoser:
            return (
              title: 'Team Game Complete',
              body:
                  'Game over. Review your feedback and prepare for the next match.',
            );
          default:
            return (title: 'Team Update', body: 'Your team status changed.');
        }
    }
  }
}
