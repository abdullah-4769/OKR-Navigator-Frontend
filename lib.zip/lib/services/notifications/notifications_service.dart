import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../../view_model/app_notifications.dart';
import 'notification_models.dart'; // Your AppNotification model

class NotificationsService {
  static final NotificationsService _instance = NotificationsService._internal();
  factory NotificationsService() => _instance;
  NotificationsService._internal();

  final FirebaseMessaging _messaging = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _local = FlutterLocalNotificationsPlugin();
  final GetStorage _storage = GetStorage();
  final GetStorage _notifBox = GetStorage('notifications');

  static const String _androidChannelId = 'high_importance_channel';
  static const String _androidChannelName = 'High Importance Notifications';
  static const String _androidChannelDesc = 'Used for critical OKR Navigator updates.';

  bool _initialized = false;
  final RxString _fcmToken = ''.obs; // Add this for reactive token updates

  // Getter for token
  String? get fcmToken => _storage.read('fcm_token');

  Future<void> init() async {
    if (_initialized) return;

    try {
      debugPrint('Initializing FCM...');

      // 1) Initialize storage first
      await GetStorage.init();
      await GetStorage.init('notifications');

      // 2) Request permissions (with error handling)
      NotificationSettings settings = await _messaging.requestPermission(
        alert: true,
        announcement: false,
        badge: true,
        carPlay: false,
        criticalAlert: false,
        provisional: false,
        sound: true,
      );

      debugPrint('Notification permission: ${settings.authorizationStatus}');

      // 3) Foreground presentation (iOS)
      await _messaging.setForegroundNotificationPresentationOptions(
        alert: true,
        badge: true,
        sound: true,
      );

      // 4) Local notifications init
      const AndroidInitializationSettings androidInit =
          AndroidInitializationSettings('@mipmap/ic_launcher');
      const DarwinInitializationSettings iosInit = DarwinInitializationSettings(
        requestAlertPermission: true,
        requestBadgePermission: true,
        requestSoundPermission: true,
      );

      const InitializationSettings initSettings = InitializationSettings(
        android: androidInit,
        iOS: iosInit,
      );

      await _local.initialize(
        initSettings,
        onDidReceiveNotificationResponse: (NotificationResponse response) {
          if (response.payload != null) {
            debugPrint('Notification tapped with payload: ${response.payload}');
          }
        },
      );

      // 5) Create Android channel
      const AndroidNotificationChannel channel = AndroidNotificationChannel(
        _androidChannelId,
        _androidChannelName,
        description: _androidChannelDesc,
        importance: Importance.max,
        playSound: true,
      );

      await _local
          .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
          ?.createNotificationChannel(channel);

      // 6) **CRITICAL: Get FCM Token with retry logic**
      await _getAndSaveFCMToken();

      // 7) Token refresh listener
      _messaging.onTokenRefresh.listen((newToken) async {
        debugPrint('FCM Token refreshed: $newToken');
        await _storage.write('fcm_token', newToken);
        _fcmToken.value = newToken;
      });

      // 8) Message streams
      FirebaseMessaging.onMessage.listen((message) async {
        debugPrint('FCM onMessage: ${message.messageId}');
        await _showFromRemoteMessage(message);
      });

      FirebaseMessaging.onMessageOpenedApp.listen((message) async {
        debugPrint('FCM onMessageOpenedApp: ${message.messageId}');
        // Handle navigation when app is opened from terminated state
      });

      // 9) Get initial message when app is opened from terminated state
      RemoteMessage? initialMessage = await _messaging.getInitialMessage();
      if (initialMessage != null) {
        debugPrint('App opened from terminated state with message: ${initialMessage.messageId}');
        await _showFromRemoteMessage(initialMessage);
      }

      _initialized = true;
      debugPrint('FCM initialization completed successfully');

    } catch (e) {
      debugPrint('FCM initialization failed: $e');
    }
  }

  // **NEW: Dedicated method for token retrieval with retry**
  Future<void> _getAndSaveFCMToken() async {
    try {
      debugPrint('Attempting to get FCM token...');

      String? token = await _messaging.getToken();

      if (token != null && token.isNotEmpty) {
        await _storage.write('fcm_token', token);
        _fcmToken.value = token;
        debugPrint('✅ FCM Token retrieved successfully: $token');
      } else {
        debugPrint('❌ FCM Token is null or empty');
        // Retry after delay
        await Future.delayed(const Duration(seconds: 2));
        await _retrieveTokenWithRetry();
      }
    } catch (e) {
      debugPrint('❌ Error getting FCM token: $e');
      await _retrieveTokenWithRetry();
    }
  }

  // **NEW: Retry mechanism**
  Future<void> _retrieveTokenWithRetry() async {
    int retries = 3;
    for (int i = 0; i < retries; i++) {
      try {
        debugPrint('Retry ${i + 1}/$retries to get FCM token...');
        await Future.delayed(Duration(seconds: (i + 1) * 2));

        String? token = await _messaging.getToken();
        if (token != null && token.isNotEmpty) {
          await _storage.write('fcm_token', token);
          _fcmToken.value = token;
          debugPrint('✅ FCM Token retrieved on retry ${i + 1}: $token');
          return;
        }
      } catch (e) {
        debugPrint('❌ Retry ${i + 1} failed: $e');
      }
    }
    debugPrint('❌ All retry attempts failed to get FCM token');
  }

  // **NEW: Manual token refresh method**
  Future<String?> refreshFCMToken() async {
    try {
      await _messaging.deleteToken(); // Force new token
      await _getAndSaveFCMToken();
      return _storage.read('fcm_token');
    } catch (e) {
      debugPrint('Error refreshing FCM token: $e');
      return null;
    }
  }

  // **NEW: Check if token exists**
  bool hasToken() {
    return _storage.read('fcm_token') != null;
  }

  // Rest of your methods remain the same...
  Future<void> _saveNotification(AppNotification notification) async {
    final List<dynamic> rawList = _notifBox.read('list') ?? [];
    final List<AppNotification> list = rawList
        .map((e) => AppNotification.fromJson(Map<String, dynamic>.from(e)))
        .toList();

    list.removeWhere((n) => n.id == notification.id);
    list.insert(0, notification);

    if (list.length > 100) list.removeRange(100, list.length);

    await _notifBox.write('list', list.map((e) => e.toJson()).toList());
  }

  List<AppNotification> getSavedNotifications() {
    final List<dynamic> rawList = _notifBox.read('list') ?? [];
    return rawList
        .map((e) => AppNotification.fromJson(Map<String, dynamic>.from(e)))
        .toList();
  }

  Future<void> markAsRead(String id) async {
    final list = getSavedNotifications();
    final index = list.indexWhere((n) => n.id == id);
    if (index != -1) {
      list[index] = list[index].copyWith(isRead: true);
      await _notifBox.write('list', list.map((e) => e.toJson()).toList());
    }
  }

  Future<void> clearAllNotifications() async {
    await _notifBox.remove('list');
  }
  // Public APIs (unchanged)
  Future<void> notifyTemplate({
    required GameMode mode,
    required String event,
    Map<String, dynamic>? vars,
  }) async {
    final t = NotificationTemplate.build(mode: mode, event: event, vars: vars);
    await _showLocalNotification(
      title: t.title,
      body: t.body,
      payload: vars == null ? null : jsonEncode(vars),
    );
  }

  Future<void> notify({
    required String title,
    required String body,
    Map<String, dynamic>? payload,
  }) async {
    await _showLocalNotification(
      title: title,
      body: body,
      payload: payload == null ? null : jsonEncode(payload),
    );
  }

  // Updated: Always save + show
  Future<void> _showFromRemoteMessage(RemoteMessage message) async {
    String? title = message.notification?.title;
    String? body = message.notification?.body;

    if (title == null || body == null) {
      final data = message.data;
      final modeStr = data['mode']?.toString();
      final event = data['event']?.toString();
      if (modeStr != null && event != null) {
        final mode = _parseMode(modeStr);
        final vars = Map<String, dynamic>.from(data);
        final template = NotificationTemplate.build(
          mode: mode,
          event: event,
          vars: vars,
        );
        title = template.title;
        body = template.body;
      }
    }

    title ??= 'Notification';
    body ??= 'You have a new update.';

    final String notifId =
        message.messageId ?? DateTime.now().millisecondsSinceEpoch.toString();

    // SAVE to history
    final appNotif = AppNotification(
      id: notifId,
      title: title,
      body: body,
      data: message.data,
      timestamp: DateTime.now(),
    );
    await _saveNotification(appNotif);

    // Show local
    await _showLocalNotification(
      title: title,
      body: body,
      payload: jsonEncode(message.data),
    );
  }

  Future<void> _showLocalNotification({
    required String title,
    required String body,
    String? payload,
  }) async {
    final details = NotificationDetails(
      android: AndroidNotificationDetails(
        _androidChannelId,
        _androidChannelName,
        channelDescription: _androidChannelDesc,
        importance: Importance.max,
        priority: Priority.high,
        icon: '@mipmap/ic_launcher',
        playSound: true,
      ),
      iOS: const DarwinNotificationDetails(),
    );

    await _local.show(
      DateTime.now().millisecondsSinceEpoch % 1000000,
      title,
      body,
      details,
      payload: payload,
    );
  }

  GameMode _parseMode(String mode) {
    switch (mode.toLowerCase()) {
      case 'solo':
        return GameMode.solo;
      case 'challenge':
        return GameMode.challenge;
      case 'campaign':
        return GameMode.campaign;
      case 'team':
        return GameMode.team;
      default:
        return GameMode.solo;
    }
  }

  // Background handler (updated to init storage)
  static Future<void> showFromBackground(RemoteMessage message) async {
    // Init storage in isolate
    await GetStorage.init();
    await GetStorage.init('notifications');

    final service = NotificationsService();
    // Init local notifs
    const AndroidInitializationSettings androidInit =
        AndroidInitializationSettings('@mipmap/ic_launcher');
    const DarwinInitializationSettings iosInit = DarwinInitializationSettings();
    const InitializationSettings initSettings = InitializationSettings(
      android: androidInit,
      iOS: iosInit,
    );
    await service._local.initialize(initSettings);

    await service._local
        .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin
        >()
        ?.createNotificationChannel(
          const AndroidNotificationChannel(
            _androidChannelId,
            _androidChannelName,
            description: _androidChannelDesc,
            importance: Importance.max,
          ),
        );

    await service._showFromRemoteMessage(message);
  }
}
